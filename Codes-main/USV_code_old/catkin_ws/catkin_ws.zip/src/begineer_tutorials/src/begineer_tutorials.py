#!/usr/bin/env python3

import roslib
roslib.load_manifest('begineer_tutorials')
import sys
import rospy
from std_msgs.msg import Int32, Int32MultiArray

from adafruit_servokit import ServoKit
import board
import busio
import time

class yuta_class():
    #############################################################
    # Subscriber Functions
    #############################################################
    def mode_read_topic_callback(self, data): #For a callback function
        self.mode_read_data = data.data
        self.kit.servo[0].angle = self.mode_read_data[0]
	self.kit.servo[1].angle = self.mode_read_data[1]





 
        print(self.mode_read_data)	

    #############################################################
    # Main Loop
    #############################################################
    def __init__(self):
	#############################################################
        # Global Variables
        #############################################################
        #example: self.dx_1_read_position_data = 0

        print('Initialization Done')

        self.i2c_bus0=(busio.I2C(board.SCL_1,board.SDA_1))
        print('Bus Initialization Done')
        self.kit = ServoKit(channels=16,i2c=self.i2c_bus0)
        print('Servo Setup Done')


        #############################################################
        # Publisher Parts
        #############################################################
        #self.pub_wonsu_send_into_roscore = rospy.Publisher("/yuta", Int32, queue_size=10)
        #############################################################
        # Subscriber Parts
        #############################################################
        # Set up your subscriber and define its callback
        self.sub_get_data_from_roscore = rospy.Subscriber("/wonsu0513", Int32MultiArray, self.mode_read_topic_callback) # points
        
       	#############################################################
        # ROS main loop
        #############################################################
        print("gogogo")
        r = rospy.Rate(100) # 10hz
        
        while not rospy.is_shutdown():         
            #self.pub_wonsu_send_into_roscore.publish(Int32(data=111111))
            
            r.sleep()
        rospy.spin()    # Spin until ctrl + c

if __name__ == '__main__':
    rospy.init_node('begineer_tutorials', anonymous=True)
    try:
        ic = yuta_class()
    except KeyboardInterrupt:
        print("Shutting down")

