# smartUSV2
The ROS package controls the Smart USV 2.0.

The USV can be controlled both manually or autonomously by providing waypoints.
