kingfisher_msgs
===============

Common messages for Kingfisher
